close all
clear all
load('../data/bananas.mat');
metamericLight(ripe,overripe);
