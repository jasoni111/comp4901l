function [ histogram, hue ] = get_hue_histogram( img, rect, k )
