[u,v] = LucasKanade(It, It1, rect)
