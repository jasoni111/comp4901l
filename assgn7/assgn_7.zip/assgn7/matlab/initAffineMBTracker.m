function [affineMBContext] = initAffineMBTracker(img, rect)
