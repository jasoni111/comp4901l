function [Wout] = affineMBTracker(img, tmp, rect, Win, context)
